<?php
include('session.php');
?>

<html>
<head><title>Life Medico</title>
	<style>
		
	b{
		margin: 50px;
		color: white;
	}
		
	
	</style>
	
	<link rel="stylesheet" href="tmainlayout.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css">
</head>
<body style="background-image: url('../Project/images/bk3.jpg');">
		<header>
			<div class="logoname">
				<img src="../Project/images/logoname.png" ></img>
			</div>
		</header>
	<div class="navigate">
	<nav>
		<ul>
			<li><a href="http://localhost/Project/main1.php">Home</a></li>
			<li class="dropdown">
					<a href="http://localhost/Project/category1.php" class ="dropbtn" >Category <i class="fa fa-caret-down"></i></a>
					<div class="dropdown-content">
						<a href="#">Ayurvedic Medicine</a>
						<a href="#">Personal Care</a>
						<a href="#">Baby Care</a> <a href="#">Health Care</a>
					</div>
			</li>
			<li><a href="http://localhost/Project/cart1.php">Cart</a></li>
			<li><a href="http://localhost/Project/about1.php">About</a></li>
			<li style="float: right;"><a href="logout.php">Logout</a></li>
	
		</ul>
	</nav>
		
	</div>
	<br><br><br>
	<img src="../Project/images/ty.png" style="float: left; width:300px; height:300px; margin:100px;"/>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "lifemedico";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "INSERT INTO products (code, pname, price)
VALUES ('A005', 'Patanjali Arogya Vati', '100')";

if ($conn->query($sql) === TRUE) {
    echo "<b>Product added to your cart successfully!!</b>";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
</body>
<html>