
<?php
include('login.php'); // Includes Login Script

if(isset($_SESSION['login_user'])){
header("location: loginaction.php");
}
?>


<html>
<head>
<style>
form{
	border:3px solid #f1f1f1
}

log{
    padding: 50px;
    color: white;
    background-color: blue;
    clear: left;
    text-align: center;
}



input[type=text],input[type=password]
{
	width=100%;
	padding:12px 10px;
	margin:8px 10;
	display:inline-black;
	border:2px solid #ccc;
	box-sizing:border-box;
}

button
{
    background-color:blue;
	color:white;
	padding:14px 20px;
	margin:18px 5;
	border:none;
	cursor:pointer;
	width:10%;
}



.imgcontainer
{
	text-align:center;
	margin:24px 0 12px 0;
}

img-avatar
{
	width:100;
	border-radius:100%;
}

.container
{
	padding:16px;
}  

span.psw
{
	padding-top=16px;
}

</style> 
<link rel="stylesheet" href="tmainlayout.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css">
	
	
	<meta charset="utf-8">
  <meta http-equiv="Content-Type" content="text/html">
  <link rel="stylesheet" type="text/css" media="all" href="css/styles.css">
  <link rel="stylesheet" type="text/css" media="all" href="css/progression.min.css">
  <script type="text/javascript" src="js/jquery-1.10.2.min.js"></script>
  <script type="text/javascript" src="js/progression.min.js"></script>
	
	
	
</head>
<body style="background-image: url('../Project/images/bk3.jpg');">
		<header>
			<div class="logoname">
				<img src="../Project/images/logoname.png" ></img>
			</div>
		</header>
	<div class="navigate">
	<nav>
		<ul>
			<li><a href="../Project/main.html">Home</a></li>
			<li class="dropdown">
					<a href="Category.html" class ="dropbtn" >Category <i class="fa fa-caret-down"></i></a>
					<div class="dropdown-content">
						<a href="#">Ayurvedic Medicine</a>
						<a href="#">Personal Care</a>
						<a href="#">Baby Care</a> <a href="#">Health Care</a>
						<a href="#">Health Care</a>
					</div>
			</li>
			<li><a href="../Project/cart.html">Cart</a></li>
			<li><a href="contact.html">About</a></li>
			<li style="float: right;"><a href="loginpage.php">Login</a></li>
			<li style="float: right;"><a href="http://localhost/Project/registration.php">Sign up</a></li>
		</ul>
	</nav>
	
	</div>
<br><br><br>

 <div id="w" style="background-image:url('');>
		<div id="content">
      <h1>Login</h1>
      
      <form id="registerform"  action="" method="post">
        <div class="formrow">
          <label for="username">Username</label>
          <input data-progression="" type="text" name="username" id="username" class="basetxt" tabindex="1" data-helper="Your username.">
          <p class="errmsg">Please add some more characters</p>
        </div>
        
        
        <div class="formrow">
          <label for="password1">Password</label>
          <input data-progression="" type="password" name="password1" id="password1" class="basetxt" tabindex="3" data-helper="Your password!">
		  <p class="errmsg">Password please</p>
        </div>
        
        
        <input type="submit" name="submit" id="submitformbtn" class="submitbtn" value="Login"><br><br>
		<div class="forget">
		<h3 style="color: white;"><span class="psw">Forgot <a href="child.html">password?</a></span></h3>
		</div>
      </form>
    </div><!-- @end #content -->
  </div><!-- @end #w -->
<script type="text/javascript">
$(function(){
  $("#registerform").progression({
    tooltipWidth: '200',
    tooltipPosition: 'right',
    tooltipOffset: '0',
    showProgressBar: false,
    showHelper: true,
    tooltipFontSize: '14',
    tooltipFontColor: 'fff',
    progressBarBackground: 'fff',
    progressBarColor: '7ea2de',
    tooltipBackgroundColor: 'a5bce5',
    tooltipPadding: '7',
    tooltipAnimate: true
  }).submit(function(e){
    return;
  });
  
  $('#username').on('blur', function(){
    var currval = $(this).val();
    
    if(currval.length < 6) {
      $(this).next('.errmsg').slideDown();
    } else {
      // the username is 6 or more characters and we hide the error
      $(this).next('.errmsg').slideUp();
    }
  });
  
  $('#email').on('blur', function(){
    // email regex source http://stackoverflow.com/a/17968929/477958
    var mailval = $(this).val();
    
    var pattern = new RegExp(/^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/);
    if(!pattern.test(mailval)) {
      $(this).next('.errmsg').slideDown();
    } else {
      $(this).next('.errmsg').slideUp();
    }
  });
  
  $('#password2').on('blur', function(){
    var pwone = $('#password1').val();
    var pwtwo = $(this).val();
    
    if(pwtwo.length < 1 || pwone != pwtwo) {
      $(this).next('.errmsg').slideDown();
    } else if(pwone == pwtwo) {
      // both passwords match and we hide the error
      $(this).next('.errmsg').slideUp();
    }
  });
});
</script>
</body>
</html>



