
<html>
<head><title>Life Medico</title>
	<style>
	</style>
	
	<link rel="stylesheet" href="tmainlayout.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css">
</head>
<body style="background-color: #00BCD4;">
		<header>
			<div class="logoname">
				<img src="../Project/images/logoname.png" ></img>
			</div>
		</header>
	<div class="navigate">
	<nav>
		<ul>
			<li><a href="../Project/main.html">Home</a></li>
			<li class="dropdown">
					<a href="#" class ="dropbtn" >Category <i class="fa fa-caret-down"></i></a>
					<div class="dropdown-content">
						<a href="#">Ayurvedic Medicine</a>
						<a href="#">Personal Care</a>
						<a href="#">Baby Care</a> <a href="#">Health Care</a>
					</div>
			</li>
			<li><a href="../Project/cart.html">Cart</a></li>
			<li><a href="contact.html">About</a></li>
			<li style="float: right;"><a href="loginpage.php">Login</a></li>
			<li style="float: right;"><a href="http://localhost/Project/registration.php">Sign up</a></li>
		</ul>
	</nav>
	
	</div>
<br><br><br>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "lifemedico";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 



 
$fname = $_POST['firstname']; 
$lname = $_POST['lastname'];
$address = $_POST['address'];
$username = $_POST['username']; 
$email = $_POST['email']; 
$password = $_POST['password1']; 


$sql1 = "INSERT INTO user (fname,lname,address,email,username,password) VALUES ('$fname','$lname','$address','$email','$username','$password')"; 
if ($conn->query($sql1) === TRUE) {
    echo "You can Login now!!";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}


$sql = "INSERT INTO login (username,password) VALUES ('$username','$password')"; 
if ($conn->query($sql) === TRUE) {
    echo "Sign up Successfull.";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}


$conn->close();
?>


</body>
</html>














