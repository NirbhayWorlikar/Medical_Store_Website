<?php
include('session.php');
?>
<html>
<head><title>Life Medico</title>

	<style>
	
.produt{
	margin: 10px;

	}
	 
h3{
	font-family: 'Cambria', cursive;
	text-transform:uppercase; 
	color:white;
	letter-spacing: 0.2em; 
	line-height: 5em;
	text-align:left;
	font-size:25px;
	
}
	 

.ipic {
  border: 10px solid #fff;  
  height: auto;
  width: 200px;
  margin: 20px;
  overflow: hidden;
   
  -webkit-box-shadow: 5px 5px 5px #111;
          box-shadow: 5px 5px 5px #111;  
}


	
	/*GROW*/
.grow img {
  height: 200px;
  width: 200px;
  
 
 
  -webkit-transition: all 1s ease;
     -moz-transition: all 1s ease;
       -o-transition: all 1s ease;
      -ms-transition: all 1s ease;
          transition: all 1s ease;
}
 
.grow img:hover {
  width: 400px;
  height: 400px;
  
}
	

div.img {
   
    border: 1px solid #ccc;
    float: left;
	width: 180px;
}

div.img:hover {
    border: 1px solid #777;
}

div.img img {
    width: 100%;
    height: auto;
}		
	
td {
	text-align: center;
	color: white;
	padding: 50px;
	background-color: gray;

}	

button{
	width: 200px;
	height: 50px;
	text-align: center;
    cursor: pointer;
    color: #63532d;
    font-size: 2.5em;
    line-height: 290px;
    border: 1px solid #cba957;
    background: #f3d078;
    background: -webkit-gradient(linear,left top,left bottom,color-stop(0%,#f7dfa5),color-stop(100%,#f0c14b));
    background: -webkit-linear-gradient(top,#f7dfa5,#f0c14b);
    background: -moz-linear-gradient(top,#f7dfa5,#f0c14b);
    background: -o-linear-gradient(top,#f7dfa5,#f0c14b);
    background: linear-gradient(top,#f7dfa5,#f0c14b);
    -webkit-box-shadow: 0 1px 0 rgba(255,255,255,0.4) inset;
    -moz-box-shadow: 0 1px 0 rgba(255,255,255,0.4) inset;
    box-shadow: 0 1px 0 rgba(255,255,255,0.4) inset;
    -webkit-border-radius: 40px;
    -moz-border-radius: 40px;
    border-radius: 40px;
}



	
	</style>
	
	<link rel="stylesheet" href="tmainlayout.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css">
</head>
<body style="background-image: url('../Project/images/bk3.jpg');">
		<header>
			<div class="logoname">
				<img src="../Project/images/logoname.png" ></img>
			</div>
		</header>
	<div class="navigate">
	<nav>
		<ul>
			<li><a href="http://localhost/Project/main1.php">Home</a></li>
			<li class="dropdown">
					<a href="http://localhost/Project/category1.php" class ="dropbtn" >Category <i class="fa fa-caret-down"></i></a>
					<div class="dropdown-content">
						<a href="#">Ayurvedic Medicine</a>
						<a href="#">Personal Care</a>
						<a href="#">Baby Care</a> <a href="#">Health Care</a>
					</div>
			</li>
			<li><a href="http://localhost/Project/cart1.php">Cart</a></li>
			<li><a href="http://localhost/Project/about1.php">About</a></li>
			<li style="float: right;"><a href="logout.php">Logout</a></li>
	
		</ul>
	</nav>
	</div>
	
	
	<br>
	
<div class="produt">	
	<h3><u> Product </u></h3>

	<center>

	<table border="2">
		<tr>
      <td colspan="3", align="center">Personal Product</td>
</tr>
<tr>
    <td rowspan="4">Hover mouse to zoom.<div class="img grow pic"><img src="../Project/images/Ayurvedic/pp7.jpg" alt="portrait"class = "tooltip" title="Price : Rs. 600/-">
						</div></td>
    <td>Product Id:</td>
    <td>P007</td>
</tr>      
<tr>
    <td>Product Name:</td>
    <td>Pedia Sure Nutrients</td>
</tr>
<tr>
    <td>Price (Rs):</td>
    <td>600/-</td>
</tr>  
<tr>
	 <td>Status:</td>
    <td>Available</td>
</tr>
 	</table>	
	<br>
	<section>
	<a href="http://localhost/Project/category1.php"><button type="button" onclick="#" >Back</button></a>	
	<a href="http://localhost/Project/cart1.php"><button type="button" onclick="#" >Add To Cart</button></a>
	</section>
	</center>
	
	</div>
	
	
	
	
	
	</body>
	</html>
	
	