<?php
include('session.php');
?>


<html>
<head><title>Life Medico</title>

	<style>
	
	.warnsymbol {
	 margin: 0 0 30px 30px;
	 float: left;
	}
	.warnmsg h1,p{
	float:center;
	text-align: center;
	}
	
	
	
	
	
	</style>
	
	<link rel="stylesheet" href="tmainlayout.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css">
</head>
<body style="background-color: #00BCD4;">
		<header>
			<div class="logoname">
				<img src="../Project/images/logoname.png" ></img>
			</div>
		</header>
	<div class="navigate">
	<nav>
		<ul>
			<li><a href="../Project/main1.php">Home</a></li>
			<li class="dropdown">
					<a href="category1.php" class ="dropbtn" >Category <i class="fa fa-caret-down"></i></a>
					<div class="dropdown-content">
						<a href="#">Ayurvedic Medicine</a>
						<a href="#">Personal Care</a>
						<a href="#">Baby Care</a>					
						<a href="#">Health Care</a>
					</div>
			</li>
			<li><a href="../Project/cart1.php">Cart</a></li>
			<li><a href="about1.php">About</a></li>
			<li style="float: right;"><a href="http://localhost/Project/logout.php">Logout</a></li>
			
		</ul>
	</nav>
	
	</div>
<br><br><br>

<div class="warnsymbol">
	<img src="../Project/images/namste.png" style="float: left; width:500px; height:430px;"/>
</div>	
	<div class="warnmsg" style="float: left;">
	<h1><b id="welcome">Welcome : <u style="color:white;"><i style="color:black;"><?php echo $login_session; ?></i></u></b> </h1>
	<br>
	<h1>Thanks for logging In!!!</h1>
	<p style="color: white;"> "Always keep filling your cart. Don't forget health is everything.<br>
	Stay Healthy Live Strong !!!"</p>
	
	</div>


</body>
</html>

