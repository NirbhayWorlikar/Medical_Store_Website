<?php
include('session.php');
?>

<html>
<head><title>Life Medico</title>

	<style>
	.w3-content1{max-width:980px;margin:auto}
	.mySlides1 {display:none;}
	</style>
	
	<link rel="stylesheet" href="tmainlayout.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css">
</head>
<body background="../Project/images/bk3.jpg" style="background-size: fit;">
		<header>
			<div class="logoname">
				<img src="../Project/images/logoname.png" ></img>
			</div>
		</header>
	<div class="navigate">
	<nav>
		<ul>
			<li><a href="#">Home</a></li>
			<li class="dropdown">
					<a href="http://localhost/Project/category1.php" class ="dropbtn" >Category <i class="fa fa-caret-down"></i></a>
					<div class="dropdown-content">
						<a href="#">Ayurvedic Medicine</a>
						<a href="#">Personal Care</a>
						<a href="#">Baby Care</a> <a href="#">Health Care</a>
					</div>
			</li>
			<li><a href="http://localhost/Project/cart1.php">Cart</a></li>
			<li><a href="http://localhost/Project/about1.php">About</a></li>
			<li style="float: right;"><a href="logout.php">Logout</a></li>
			
		</ul>
	</nav>
	
	</div>
<br><br><br>

	<div class="w3-content" style="max-width:1000px; max-height:500px; position:relative; box-shadow: 0 0 20px rgba(0,0,0,0.4);">
		<img class="mySlides" src="../Project/images/slider/1.jpg" style="width:100%; height:100%">
		<img class="mySlides" src="../Project/images/slider/2.jpg" style="width:100%; height:100%">
		<img class="mySlides" src="../Project/images/slider/3.jpg" style="width:100%; height:100%">
		<img class="mySlides" src="../Project/images/slider/4.jpg" style="width:100%; height:100%">


		<a class="w3-btn-floating" style="position:absolute;top:45%;left:0;background-color:green;" onclick="plusDivs(-1)">&#10094;</a>
		<a class="w3-btn-floating" style="position:absolute;top:45%;right:0;background-color:green;" onclick="plusDivs(1)">&#10095;</a>
	</div>
<script>

	var slideIndex = 1;
	showDivs(slideIndex);

	function plusDivs(n) {
		showDivs(slideIndex += n);
	}

	function showDivs(n) {
		var i;
		var x = document.getElementsByClassName("mySlides");
		if (n > x.length) {slideIndex = 1}
		if (n < 1) {slideIndex = x.length}
		for (i = 0; i < x.length; i++) {
			x[i].style.display = "none";
		}
		x[slideIndex-1].style.display = "block";
	}
</script>

 
 
<br><br><br>
 
	<h4 style="color:white; margin:10px;"><b><u>Brands<u></h4>
	<hr>
	<section>
		<ul>
			<li><img src="../Project/images/brands/1.jpg" style="max-width:200px; max-height:100px; float:left; width:100%; height:100%"/> </li>
			<li><img src="../Project/images/brands/2.jpg" style="max-width:400px; max-height:100px; float:left; width:100%; height:100%"/> </li>
			<li><img src="../Project/images/brands/3.png" style="max-width:600px; max-height:100px; float:left; width:100%; height:100%"/> </li>
			<li><img src="../Project/images/brands/4.jpg" style="max-width:600px; max-height:100px; float:left; width:100%; height:100%"/> </li>
			<li><img src="../Project/images/brands/5.jpg" style="max-width:400px; max-height:100px; float:left; width:100%; height:100%"/> </li>
			<li><img src="../Project/images/brands/p.png" style="max-width:600px; max-height:100px; float:left; width:100%; height:100%"/> </li>
			<li><img src="../Project/images/brands/6.png" style="max-width:300px; max-height:100px; float:left; width:100%; height:100%"/> </li>

		</ul>

	</section>
	<hr>
<br><br>
	<section>
		<div class="w3-content1" style="max-width:400px">
	
			<img class= "mySlides1" src="../Project/images/brands/p.png" style="width:300px; height:100px"/>
			<img class= "mySlides1" src="../Project/images/brands/2.jpg" style="width:300px; height:100px"/>
			<img class= "mySlides1" src="../Project/images/brands/3.png" style="width:300px; height:100px"/>
			<img class= "mySlides1" src="../Project/images/brands/4.jpg" style="width:300px; height:100px"/>
			<img class= "mySlides1" src="../Project/images/brands/5.png" style="width:300px; height:100px"/>
			<img class= "mySlides1" src="../Project/images/brands/6.png" style="width:300px; height:100px"/>
			<img class= "mySlides1" src="../Project/images/brands/8.png" style="width:300px; height:100px"/> 
		</div>
	</section>
	<br><br>
	<hr>
	<br><br>
 
	<script>
		var slideIndexq = 0;
		carousel();

		function carousel() {
			var i;
			var m = document.getElementsByClassName("mySlides1");
			for (i = 0; i < m.length; i++) {
				m[i].style.display = "none";
			}
			slideIndexq++;
			if (slideIndexq > m.length) {slideIndexq = 1}
			m[slideIndexq-1].style.display = "block";
			setTimeout(carousel, 1000);
		}
</script>



</body>
</html>


