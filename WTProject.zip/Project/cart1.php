<?php
include('session.php');
?>

<html>
<head><title>Life Medico</title>
	<style>
	
	table, th, td {
     border: 1px solid white;
	 text-align: center;
	 color: white;
	 padding: 4px;
	 overflow: hidden;
	}
	
	.userdata {
		color:white;
		margin: 50px;
		
	}
	.cart{
		color: white;
	}
	
	
	
	button{
	width: 150px;
	text-align: center;
    cursor: pointer;
    color: #63532d;
    font-size: 2.5em;
    line-height: 290px;
    border: 1px solid #cba957;
    background: #f3d078;
    background: -webkit-gradient(linear,left top,left bottom,color-stop(0%,#f7dfa5),color-stop(100%,#f0c14b));
    background: -webkit-linear-gradient(top,#f7dfa5,#f0c14b);
    background: -moz-linear-gradient(top,#f7dfa5,#f0c14b);
    background: -o-linear-gradient(top,#f7dfa5,#f0c14b);
    background: linear-gradient(top,#f7dfa5,#f0c14b);
    -webkit-box-shadow: 0 1px 0 rgba(255,255,255,0.4) inset;
    -moz-box-shadow: 0 1px 0 rgba(255,255,255,0.4) inset;
    box-shadow: 0 1px 0 rgba(255,255,255,0.4) inset;
    -webkit-border-radius: 40px;
    -moz-border-radius: 40px;
    border-radius: 40px;
}
	
	</style>
	
	<link rel="stylesheet" href="tmainlayout.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css">
</head>
<body style="background-image: url('../Project/images/bk3.jpg');">
		<header>
			<div class="logoname">
				<img src="../Project/images/logoname.png" ></img>
			</div>
		</header>
	<div class="navigate">
	<nav>
		<ul>
			<li><a href="http://localhost/Project/main1.php">Home</a></li>
			<li class="dropdown">
					<a href="http://localhost/Project/category1.php" class ="dropbtn" >Category <i class="fa fa-caret-down"></i></a>
					<div class="dropdown-content">
						<a href="#">Ayurvedic Medicine</a>
						<a href="#">Personal Care</a>
						<a href="#">Baby Care</a> <a href="#">Health Care</a>
					</div>
			</li>
			<li><a href="http://localhost/Project/cart1.php">Cart</a></li>
			<li><a href="http://localhost/Project/about1.php">About</a></li>
			<li style="float: right;"><a href="logout.php">Logout</a></li>
	
		</ul>
	</nav>
		
	</div>




<div class ="Userdata">
	<h3><b> Username : </b><u style="color:#00BCD4;"><?php echo $login_session; ?> </u></h3>

	<?php
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "lifemedico";

	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	// Check connection
	if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
	} 

	$use = $login_session;


	$sql1 = "SELECT fname, lname, address, email FROM user where username = '$use'";
	$result = $conn->query($sql1);

	if ($result->num_rows > 0) {
     // output data of each row
     while($row = $result->fetch_assoc()) {
         echo "<h3><b>Name: </b>". $row["fname"]. "  ". $row["lname"].".<b>  &nbsp;   Email id: </b>". $row["email"] ."<b><br> Address: </b>". $row["address"] . "<br></h3>";
		}
	} else {
     echo "0 results";
	}	

	
	?>  
</div>


<hr>

<div class="cart">
	<center>
	<?php
	$sql = "SELECT code, pname, price FROM products";
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
		echo "<table><tr><th>Product Code</th><th>Product Name</th><th>Price</th><th><?php /*Confirm*/ ?></th></tr>";
		// output data of each row
		while($row = $result->fetch_assoc()) {
         echo "<tr><td>" . $row["code"]. "</td><td>" . $row["pname"]. "</td><td>" . $row["price"]. "</td><td><?php /*X*/ ?></td></tr>";
		}
		echo "</table>";
	} else {
		echo "<b>No Products in Your Cart <b>";
	}
?>

	<br>
	
	<?php
	
	$sql = "SELECT sum(price) as total FROM products";
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			echo "Total Price : " . $row["total"]. "<br>";
			}
		}
		else {
		echo "No Product";
	}
	
	$conn->close();
	?>  
		</center>
</div>
<br>
<div class="checkout">	
	<section>
	<center>
		<a href="http://localhost/Project/emptycart.php"><button type="button">Empty Cart</button></a>&nbsp;	
		<a href="http://localhost/Project/tybuy.php"><button type="button" onclick="#" >Checkout</button></a>
	</center>
	</section>

	</div>
</body>
</html>