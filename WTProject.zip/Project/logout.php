<?php
session_start();
if(session_destroy()) // Destroying All Sessions
{
header("Location: loginpage.php"); // Redirecting To Home Page
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "lifemedico";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "DELETE FROM products";

if ($conn->query($sql) === TRUE) {
    echo "";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

?>