<?php
include('session.php');
?>
<html>
<head>

<title>Life Medico</title>

	<style>
	.produt{
	margin: 10px;

	}
	 
h3{
	font-family: 'Cambria', cursive;
	text-transform:uppercase; 
	color:white;
	letter-spacing: 0.2em; 
	line-height: 5em;
	text-align:left;
	font-size:25px;
	
}
	 

.ipic {
  border: 10px solid #fff;  
  height: auto;
  width: 200px;
  margin: 20px;
  overflow: hidden;
   
  -webkit-box-shadow: 5px 5px 5px #111;
          box-shadow: 5px 5px 5px #111;  
}


	
	/*GROW*/
.grow img {
  height: 200px;
  width: 200px;
  
 
 
  -webkit-transition: all 1s ease;
     -moz-transition: all 1s ease;
       -o-transition: all 1s ease;
      -ms-transition: all 1s ease;
          transition: all 1s ease;
}
 
.grow img:hover {
  width: 400px;
  height: 400px;
  
}
	

div.img {
   
    border: 1px solid #ccc;
    float: left;
    width: 180px;
}

div.img:hover {
    border: 1px solid #777;
}

div.img img {
    width: 100%;
    height: auto;
}	
div.desc {
    padding: 15px;
    text-align: center;
	color: white;
	}

.tooltipster-punk {
	border-radius: 5px; 
	border-bottom: 3px solid #f71169;
	background: #2a2a2a;
	color: #fff;
}
.tooltipster-punk .tooltipster-content {
	font-family: 'Courier', monospace;
	font-size: 14px;
	line-height: 16px;
	padding: 8px 10px;
}
 

	
	</style>
	
	<link rel="stylesheet" href="tmainlayout.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css">
	
	
	
	<link rel="stylesheet" type="text/css" href="css/tooltipster.css" />
	<script type="text/javascript" src="http://code.jquery.com/jquery-2.0.0.min.js"></script>
	<script type="text/javascript" src="js/jquery.tooltipster.js"></script>
	
	
	<script type="text/javascript">
		$(document).ready(function() {
			 $('.tooltip').tooltipster();
		});
	</script>
	
	
	
</head>
<body style="background-image: url('../Project/images/bk3.jpg');">
		<header>
			<div class="logoname">
				<img src="../Project/images/logoname.png" ></img>
			</div>
		</header>
	<div class="navigate">
	<nav>
		<ul>
			<li><a href="http://localhost/Project/main1.php">Home</a></li>
			<li class="dropdown">
					<a href="#" class ="dropbtn" >Category <i class="fa fa-caret-down"></i></a>
					<div class="dropdown-content">
						<a href="#">Ayurvedic Medicine</a>
						<a href="#">Personal Care</a>
						<a href="#">Baby Care</a> <a href="#">Health Care</a>
					</div>
			</li>
			<li><a href="http://localhost/Project/cart1.php">Cart</a></li>
			<li><a href="http://localhost/Project/about1.php">About</a></li>
			<li style="float: right;"><a href="logout.php">Logout</a></li>
			
		</ul>
	</nav>
	
	</div>
<br>

<div class="produt">


<section style="float: left;">
<h3><u> Ayurvedic Herbs & Medicines</u></h3>
	
	<div class="img ipic">
		<a href="http://localhost/Project/a1.php">
			<img src="../Project/images/Ayurvedic/aa1.jpg" alt="potrait" class = "tooltip" title="Price : Rs. 200/-" width="300" height="200">
		</a>
		<div class="desc">Adulsa Herb</div>
	</div>
	
	 <div class="img ipic">
		<a href="http://localhost/Project/a2.php">
			<img src="../Project/images/Ayurvedic/aa2.jpg" alt="potrait" width="300" height="200" class = "tooltip" title="Price : Rs. 300/-">
		</a>
		<div class="desc">Agar Aloewood Herb</div>
	</div>
	
	<div class="img ipic">
		<a href="http://localhost/Project/a3.php">
			<img src="../Project/images/Ayurvedic/aa4.png" alt="potrait" width="300" height="200" class = "tooltip" title="Price : Rs. 200/-">
		</a>
		<div class="desc">Ajmoda Herb</div>
	</div>
	
	<div class="img ipic">
		<a href="http://localhost/Project/a4.php">
			<img src="../Project/images/Ayurvedic/aa3.jpg" alt="potrait" width="300" height="200" class = "tooltip" title="Price : Rs. 400/-">
		</a>
		<div class="desc">Sativum Herb </div>
	</div>

	<div class="img ipic">
		<a href="http://localhost/Project/a5.php">
			<img src="../Project/images/Ayurvedic/aa5.jpg" alt="potrait" width="300" height="200" class = "tooltip" title="Price : Rs. 100/-">
		</a>
		<div class="desc">Patanjali Arogya vati</div>
	</div>

	<div class="img ipic">
		<a href="http://localhost/Project/a6.php">
			<img src="../Project/images/Ayurvedic/aa6.jpg" alt="potrait" width="300" height="200" class = "tooltip" title="Price : Rs. 200/-">
		</a>
		<div class="desc">Aloevera Syrup</div>
	</div>
			
</section>


<br>
<section style="float: left;">
<br><br>
<h3><u> Personal Care </u></h3>

   <div class="img ipic">
		<a href="http://localhost/Project/p1.php">
			<img src="../Project/images/Ayurvedic/pp1.jpg" alt="potrait" class = "tooltip" title="Price : Rs. 300/-" width="300" height="100">
		</a>
		<div class="desc">Himalaya Antidandruff cream </div>
	</div>
	
	 <div class="img ipic">
		<a href="http://localhost/Project/p2.php">
			<img src="../Project/images/Ayurvedic/pp2.jpg" alt="potrait" width="300" height="200" class = "tooltip" title="Price : Rs. 400/-">
		</a>
		<div class="desc">Himalaya Anti-Hairfall Shampoo</div>
	</div>
	<div class="img ipic">
		<a href="http://localhost/Project/p3.php">
			<img src="../Project/images/Ayurvedic/pp3.jpg" alt="potrait" width="300" height="200" class = "tooltip" title="Price : Rs. 300/-">
		</a>
		<div class="desc">Himalaya Sunscreen Lotion</div>
	</div>
	 <div class="img ipic">
		<a href="http://localhost/Project/p4.php">
			<img src="../Project/images/Ayurvedic/pp4.jpg" alt="potrait" width="300" height="200" class = "tooltip" title="Price : Rs. 100/-">
		</a>
		<div class="desc">Sensodyne toothpaste</div>
	</div>
	 <div class="img ipic">
		<a href="http://localhost/Project/p5.php">
			<img src="../Project/images/Ayurvedic/pp5.jpg" alt="potrait" width="300" height="200" class = "tooltip" title="Price : Rs. 100/-">
		</a>
		<div class="desc">Glucon D glucose plus</div>
	</div>
		 <div class="img ipic">
		<a href="http://localhost/Project/p6.php">
			<img src="../Project/images/Ayurvedic/pp6.jpg" alt="potrait" width="300" height="200" class = "tooltip" title="Price : Rs. 200/-">
		</a>
		<div class="desc">Calcium Sandos Women</div>
	</div>
		 <div class="img ipic">
		<a href="http://localhost/Project/p7.php">
			<img src="../Project/images/Ayurvedic/pp7.jpg" alt="potrait" width="300" height="200" class = "tooltip" title="Price : Rs. 600/-">
		</a>
		<div class="desc">Pedia Sure Nutrients</div>
	</div>
	 <div class="img ipic">
		<a href="http://localhost/Project/p8.php">
			<img src="../Project/images/Ayurvedic/pp8.jpg" alt="potrait" width="300" height="200" class = "tooltip" title="Price : Rs. 900/-">
		</a>
		<div class="desc">Nutricare Whey Protein</div>
	</div>	
	 <div class="img ipic">
		<a href="http://localhost/Project/p9.php">
			<img src="../Project/images/Ayurvedic/pp9.jpg" alt="potrait" width="300" height="200" class = "tooltip" title="Price : Rs. 100/-">
		</a>
		<div class="desc">Whisper Women Sanitory Pads</div>
	</div>
	 <div class="img ipic">
		<a href="http://localhost/Project/p10.php">
			<img src="../Project/images/Ayurvedic/pp10.jpg" alt="potrait" width="300" height="200" class = "tooltip" title="Price : Rs. 300/-">
		</a>
		<div class="desc">Himalaya Under Eye Cream</div>
	</div>
	 <div class="img ipic">
		<a href="http://localhost/Project/p11.php">
			<img src="../Project/images/Ayurvedic/pp11.jpg" alt="potrait" width="300" height="200" class = "tooltip" title="Price : Rs. 500/-">
		</a>
		<div class="desc">Nutrigain Fitness Powder</div>
	</div>
	 <div class="img ipic">
		<a href="http://localhost/Project/p12.php">
			<img src="../Project/images/Ayurvedic/pp12.jpg" alt="potrait" width="300" height="200" class = "tooltip" title="Price : Rs. 300/-">
		</a>
		<div class="desc">AXE Signature Body Deodrant</div>
	</div>	
	
</section>



<br>
<section>
<br><br>
<h3><u> Baby Care </u></h3>

   <div class="img ipic">
		<a href="http://localhost/Project/b1.php">
			<img src="../Project/images/Ayurvedic/bb1.jpg" alt="potrait" width="300" height="200" class = "tooltip" title="Price : Rs. 500/-">
		</a>
		<div class="desc">Pampers Baby Diapers</div>
	</div>
	
	 <div class="img ipic">
		<a href="http://localhost/Project/b2.php">
			<img src="../Project/images/Ayurvedic/bb2.jpg" alt="potrait" width="300" height="200" class = "tooltip" title="Price : Rs. 300/-">
		</a>
		<div class="desc">Himalaya Diaper Rash Cream</div>
	</div>
	<div class="img ipic">
		<a href="http://localhost/Project/b3.php">
			<img src="../Project/images/Ayurvedic/bb3.jpg" alt="potrait" width="300" height="200" class = "tooltip" title="Price : Rs. 200/-">
		</a>
		<div class="desc">Nestle Lactogen Powder</div>
	</div>
	 <div class="img ipic">
		<a href="http://localhost/Project/b4.php">
			<img src="../Project/images/Ayurvedic/bb4.jpg" alt="potrait" width="300" height="200" class = "tooltip" title="Price : Rs. 200/-">
		</a>
		<div class="desc">Baby Milk Body Lotion</div>
	</div>
	 <div class="img ipic">
		<a href="http://localhost/Project/b5.php">
			<img src="../Project/images/Ayurvedic/bb5.jpg" alt="potrait" width="300" height="200" class = "tooltip" title="Price : Rs. 100/-">
		</a>
		<div class="desc">Johnson's Baby Soap </div>
	</div>
	 <div class="img ipic">
		<a href="http://localhost/Project/b6.php">
			<img src="../Project/images/Ayurvedic/bb6.jpg" alt="potrait" width="300" height="200" class = "tooltip" title="Price : Rs. 200/-">
		</a>
		<div class="desc">Johnson's Baby Shampoo</div>
	</div>	
	 
</section>

<br>
<section>
<br><br>
<h3><u> Health Care </u></h3>

   <div class="img ipic">
		<a href="http://localhost/Project/h1.php">
			<img src="../Project/images/Ayurvedic/hh1.jpg" alt="potrait" width="300" height="200" class = "tooltip" title="Price : Rs. 200/-">
		</a>
		<div class="desc">Benadryl Allergy & Cold</div>
	</div>
	
	 <div class="img ipic">
		<a href="http://localhost/Project/h2.php">
			<img src="../Project/images/Ayurvedic/hh2.jpg" alt="potrait" width="300" height="200" class = "tooltip" title="Price : Rs. 300/-">
		</a>
		<div class="desc">Vicks Cough Syrup Honey</div>
	</div>
	<div class="img ipic">
		<a href="http://localhost/Project/h3.php">
			<img src="../Project/images/Ayurvedic/hh3.jpg" alt="potrait" width="300" height="200" class = "tooltip" title="Price : Rs. 400/-">
		</a>
		<div class="desc">CLET-OF Antibiotics Tablets</div>
	</div>
	 <div class="img ipic">
		<a href="http://localhost/Project/h4.php">
			<img src="../Project/images/Ayurvedic/hh4.jpg" alt="potrait" width="300" height="200" class = "tooltip" title="Price : Rs. 200/-">
		</a>
		<div class="desc">NimuDay Fever & Pain Tablets</div>
	</div>
	 <div class="img ipic">
		<a href="http://localhost/Project/h5.php">
			<img src="../Project/images/Ayurvedic/hh5.jpg" alt="potrait" width="300" height="200" class = "tooltip" title="Price : Rs. 800/-">
		</a>
		<div class="desc">Nurofen Plus Painkillers</div>
	</div>
	 <div class="img ipic">
		<a href="http://localhost/Project/h6.php">
			<img src="../Project/images/Ayurvedic/hh6.jpg" alt="potrait" width="300" height="200" class = "tooltip" title="Price : Rs. 500/-">
		</a>
		<div class="desc">Schiff Digestive Pills</div>
	</div>	
	 
</section>
</div>
</body>
</html>










