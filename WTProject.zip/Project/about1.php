<?php
include('session.php');
?>
<html>
<head>
<style>
button
{
	-moz-border-radius: 6px;
 	border-radius: 6px;
   	 border:solid 1px black;
   	background-color:red;
	color:white;
	padding:14px 10px;
	margin:1px 5;
	border:none;
	cursor:pointer;
	width:20%;
	}

.cont {
	display:block;
	display:inline-block;
	margin-left:200px;
	margin-right:200px;
	text-align:left;
	border:1px solid black;
	padding-left:16px;
	padding-right:40px;
	}

.logo
img {
  border-radius: 10%;
  -webkit-transition: -webkit-transform .8s ease-in-out;
          transition:         transform .8s ease-in-out;
}

img:hover {
  -webkit-transform: rotate(360deg);
          transform: rotate(360deg);
}

</style>
<link rel="stylesheet" href="tmainlayout.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css">
</head>
<body style="background-image:url('../Project/images/bk7.jpg'); background-size: fit;">
		<header>
			<div class="logoname">
				<img src="../Project/images/logoname.png" ></img>
			</div>
		</header>
	<div class="navigate">
	<nav>
		<ul>
			<li><a href="http://localhost/Project/main1.php">Home</a></li>
			<li class="dropdown">
					<a href="http://localhost/Project/category1.php" class ="dropbtn" >Category <i class="fa fa-caret-down"></i></a>
					<div class="dropdown-content">
						<a href="#">Ayurvedic Medicine</a>
						<a href="#">Personal Care</a>
						<a href="#">Baby Care</a> <a href="#">Health Care</a>
					</div>
			</li>
			<li><a href="http://localhost/Project/cart1.php">Cart</a></li>
			<li><a href="contact.html">About</a></li>
			<li style="float: right;"><a href="logout.php">Logout</a></li>
	
		</ul>
	</nav>
	
	</div>
<br><br><br>
<div class="cont" style="background-Color:EBD43F">
<font color="red" font face="Arial Rounded MT Bold"><b><h1>About Us</h1></b></font>
<hr>
<div class="logo">
<img src="../Project/images/logo.png" style="float: left;" />
</div>
<p><font size="5" font face="Arial Rounded MT Bold">Online Medical Store is the one of the largest Medicine and Medical Equipment distributor across the India specially in Mumbai. Health care or healthcare is the diagnosis, treatment, and prevention of disease, illness, injury, and other physical and mental impairments in human beings. Health care is delivered by practitioners in allied health, dentistry, midwifery (obstetrics), medicine, optometry, pharmacy, psychology and other health professions. It refers to the work done in providing primary care, secondary care, and tertiary care, as well as in public health.</p></font>
<font color="red" font face="Arial Rounded MT Bold"><b><h1>Contact Us</h1></b></font>
<hr>

	<div class="cont"  style="margin:5px 5px"><br>
	
	
	
	<form name="feedback"  method="post" action="http://localhost/Project/feed.php" onsubmit="return processform()">
		<b>Name:</b><br>
		<input type="text" name="n" id="name" placeholder="Name" size="50"><br>
		<b>Email_id</b><br>
		<input type="email" name="e" id="email" placeholder="for example:abc@gmail.com" size="50"><br>
		<b>Review</b><br>
		<textarea cols="50" rows="5" name="message" id="essage"></textarea><br>
		<b>Any change you want?</b><br>
		<textarea cols="50" rows="5" name="message" id="message"></textarea><br><br>
	
	</div>


	<div class="cont"  style="margin:5px 5px" style="background-color:red"><br>
 		<b><font color="red">EMAIL</b></font><br>
 		<font face="Arial Rounded MT Bold" font size="3">lifemedico@gmail.com</font><br><br>
 		<b><font color="red">TELEPHONE</b></font><br>
 		+91 8422062539<br><br>
 		<b><font color="red">SKYPE</b></font><br>
 		Life_Medico<br><br>
 		<b><font color="red">ADDRESS</b></font><br>
		Life-Medico Medical Store<br>
 		Beside Trident Heights<br>
 		Worli<br>
 		Mumbai- 400030 <br>
 		Maharashra<br>
 		India<br>
			<a  href="http://www.facebook.com">Facebook</a>	
			<a  href="http://twitter.com" >Twitter</a><br><br>
 	</div>
<br>
<h3 align="right"><button type="submit" name="submit">S E N D</button></h3>
<br>
</form>
</div>

<br>
<script language="JavaScript" type="text/JavaScript">

function processform()
{
return (verifyNull() && verifyEmail());
}

function verifyNull(){
var isValid = true;
if(!document.getElementById('name').value.trim().length){
            isValid = false;
            alert('Please enter your name');
        }
        else if(!document.getElementById('message').value.trim().length){
        isValid = false;
            alert('Please enter message');
        }
      return isValid;
}

function verifyEmail(){
        var x = document.getElementById('email').value;
        var atpos = x.indexOf("@");
        var dotpos = x.lastIndexOf(".");
        if (atpos< 1 || dotpos<atpos+2 || dotpos+2>=x.length) {
            alert("Not a valid e-mail address");
        return false;
        }
       return true;
    }
</script>
</body>
</html>