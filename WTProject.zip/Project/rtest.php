<html>
<body>
<h1>A small example page to insert some data in to the MySQL database using PHP</h1>
<form action="test.php" method="post">
Firstname: <input type="text" name="firstname" /><br><br>
Lastname: <input type="text" name="lastname" /><br><br>
 Address: <input type="text" name="address" /><br><br>
email: <input type="text" name="email" /><br><br>
username: <input type="text" name="username" /><br><br>
paa: <input type="text" name="password1" /><br><br>
<input type="submit" />
</form>
</body>
</html>